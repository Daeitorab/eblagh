<?php

$TOKEN = "6423163846:AAGY00Zm3o9NQHaq2ticBK9VDRofmYfQErI"; // Your Bot Token

$ID = -1002416686134; // Your User ID

$ChUsername = "Channel Username"; // Your Channel User Name

?>